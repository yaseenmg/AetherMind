package com.yaseen.aicore.tool.impl;
import com.yaseen.aicore.tool.JsonArgs;
import com.yaseen.aicore.autonomy.MaintenanceController;import com.yaseen.aicore.entity.CompanionEntity;import com.yaseen.aicore.tool.AITool;import net.minecraft.server.level.ServerPlayer;
public final class MaintenanceTool implements AITool{public String name(){return "inspect_base_maintenance";}public String description(){return "Inspect nearby real block entities for low Forge Energy and report maintenance candidates.";}public String schema(){return "{\"radius\":number(optional)}";}public String execute(CompanionEntity c,ServerPlayer p,String a){int r=num(a,"radius",12);return MaintenanceController.scan(c,r);}private int num(String s,String n,int d){return JsonArgs.integer(s,n,d);}}
